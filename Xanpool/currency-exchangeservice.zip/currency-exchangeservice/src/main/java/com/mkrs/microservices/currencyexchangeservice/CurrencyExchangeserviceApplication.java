package com.mkrs.microservices.currencyexchangeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyExchangeserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchangeserviceApplication.class, args);
	}

}
