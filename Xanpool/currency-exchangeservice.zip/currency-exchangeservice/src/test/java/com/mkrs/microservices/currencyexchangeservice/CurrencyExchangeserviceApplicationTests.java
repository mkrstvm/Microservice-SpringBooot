package com.mkrs.microservices.currencyexchangeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyExchangeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
